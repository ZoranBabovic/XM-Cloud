Copy the following libraries to this folder:
Spe.dll
Sitecore.Kernel.dll